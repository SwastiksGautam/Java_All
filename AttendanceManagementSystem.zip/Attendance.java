public class Attendance {
    int studentId;
    String date;
    boolean present;

    public Attendance(int studentId, String date, boolean present) {
        this.studentId = studentId;
        this.date = date;
        this.present = present;
    }
}